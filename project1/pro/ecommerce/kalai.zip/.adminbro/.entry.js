AdminBro.UserComponents = {}
import Component1 from '../components/admin-imgPath-component'
AdminBro.UserComponents.Component1 = Component1
import Component2 from '../components/admin-order-component'
AdminBro.UserComponents.Component2 = Component2
import Component3 from '../components/admin-dashboard-component'
AdminBro.UserComponents.Component3 = Component3